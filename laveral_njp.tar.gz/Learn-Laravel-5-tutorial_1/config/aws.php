<?php

return [
   'key'         => 'AKIAIXGXRS6IHTVI23QQ',
   'secret'      => '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',
   'region'      => 'ap-northeast-1',
   'config_file' => null,
]
