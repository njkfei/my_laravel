## Laravel 5 系列入门教程


###此为代码示例，教程地址：

> [Laravel 5 系列入门教程（一）【最适合中国人的 Laravel 教程】](http://lvwenhan.com/laravel/432.html)

***有问题可以直接在教程下面留言***

> ###别忘了点击上面右侧的 Star 哦，变成 Unstar 就可以了！ :stuck_out_tongue_winking_eye:

### License

本示例项目继承自 Laravel 采用的 [MIT license](http://opensource.org/licenses/MIT)，你可以利用采用该协议的代码做任何事情，只需要继续继承 MIT 协议即可。
